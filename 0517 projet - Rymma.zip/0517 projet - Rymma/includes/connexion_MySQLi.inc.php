<?php

$dbServername = "localhost";
$dbUserername = "root";
$dbPassword = "";
$dbName = "sportedin";

$connexion = mysqli_connect($dbServername,$dbUserername,$dbPassword,$dbName);
// mysqli_query($connexion,"SET NAMES utf8");
?>